Rails.application.routes.draw do
  resources :artists
  resources :tracks
  resources :albums
  get 'export', to: 'artists#export'
  get 'album', to: 'albums#search'
  get 'track', to: 'tracks#search'
  get 'artist', to: 'artists#search'


  # For details on the DSL available within this file, see https://guides.rubyonrails.org/routing.html
end
