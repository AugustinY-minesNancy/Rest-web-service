class Album < ApplicationRecord
end
