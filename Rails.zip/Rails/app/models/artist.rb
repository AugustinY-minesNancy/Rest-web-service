class Artist < ApplicationRecord
  has_many :album
end
