### DEEZER_API

## Technical Prerequisite

```
ruby-v 2.7.1
```

```
rails-v 6.0.3.1
```

```
postgresql 12.3
```


## Installation


Clone my repo
```
git clone https://github.com/AugustinY-minesNancy/Rest-web-service
```

Get into it
```
cd deezer
```

Add gems
```
bundle install
```

Check routes
```
rails routes
```

Launch local server on localhost:3000
```
rails server
```

Try some requests with Postman for instance
```



##Explanation

I used rails for its simplicity to generate an api efficiently in a few CLI (cf. scaffold).
Please launch the server before any test via postman

Basic Rest API methods work, but the special methods requested doesn't work yet. 
I then try to implement them with Flask on python.