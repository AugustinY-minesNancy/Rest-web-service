class CreateAlbums < ActiveRecord::Migration[6.0]
  def change
    create_table :albums do |t|
      t.string :tags
      t.timestamps
    end
    add_index :albums, :tags
  end
end
