require 'faker'

Artist.destroy_all
Album.destroy_all
Track.destroy_all


50.times do
  Artist.create(
    first_name: Faker::Name.first_name,
    last_name: Faker::Name.last_name,
    tags: Faker::Music.genre
  )
end

100.times do
  Album.create(tags: Faker::Music.genre)
end

500.times do
  Track.create(tags: Faker::Music.genre)
end